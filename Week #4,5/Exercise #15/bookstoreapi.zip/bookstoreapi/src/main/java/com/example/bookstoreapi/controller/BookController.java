package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.dto.BookDTO;
import com.example.bookstoreapi.entity.Book;


import com.example.bookstoreapi.metrics.CustomMetricsService;
import com.example.bookstoreapi.service.BookService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Books", description = "Operations related to books in the bookstore")
@RestController
@RequestMapping("/books")
public class BookController {
	@Autowired
    private BookService bookService;
	@Autowired
    private CustomMetricsService customMetricsService;
	
	@GetMapping("/update-metric")
    public String updateMetric() {
        customMetricsService.incrementCustomMetric();
        return "Custom metric updated!";
    }

	@Operation(summary = "Get all books", description = "Retrieve a list of all books with pagination")
    @GetMapping
    public ResponseEntity<Page<Book>> getAllBooks(Pageable pageable) {
        Page<Book> books = bookService.getAllBooks(pageable);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

	@Operation(summary = "Get book by ID", description = "Retrieve a book by its ID")
    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable Long id) {
        Book book = bookService.getBookById(id)
                               .orElseThrow(() -> new RuntimeException("Book not found with id: " + id));

        BookDTO bookDTO = convertToDTO(book);

        return new ResponseEntity<>(bookDTO, HttpStatus.OK);
    }
	
	private BookDTO convertToDTO(Book book) {
        BookDTO bookDTO = new BookDTO();
        bookDTO.setId(book.getId());
        bookDTO.setTitle(book.getTitle());
        bookDTO.setAuthor(book.getAuthor());
        bookDTO.setPrice(book.getPrice());
        return bookDTO;
    }
	
    @Operation(summary = "Create a new book", description = "Add a new book to the bookstore")
    @PostMapping
    public ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDTO) {
        BookDTO createdBookDTO = new BookDTO(bookDTO.getId(), bookDTO.getTitle(), bookDTO.getAuthor());

        return new ResponseEntity<>(createdBookDTO, HttpStatus.CREATED);
    }

    @Operation(summary = "Update a book", description = "Update the details of a book by its ID")
    @PutMapping("/{id}")
    public ResponseEntity<BookDTO> updateBook(@PathVariable Long id, @RequestBody BookDTO bookDTO) {
       
        Book book = convertToEntity(bookDTO);

        Book updatedBook = bookService.updateBook(id, book);

        BookDTO updatedBookDTO = convertToDTO(updatedBook);

        return new ResponseEntity<>(updatedBookDTO, HttpStatus.OK);
    }

    private Book convertToEntity(BookDTO bookDTO) {
        Book book = new Book(bookDTO.getId(),bookDTO.getTitle(),bookDTO.getAuthor());
        return book;
    }

    @Operation(summary = "Delete a book", description = "Remove a book from the bookstore")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
